
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.storage.jsonstore import JsonStore
import random

store = JsonStore("autosave.json")

class MainMenu(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        layout.add_widget(Label(text='Star Fall', font_size=32))
        start_btn = Button(text='Start Game', size_hint=(1, 0.2))
        start_btn.bind(on_release=lambda x: self.start_game())
        layout.add_widget(start_btn)
        self.add_widget(layout)

    def start_game(self):
        if 'player' in store:
            App.get_running_app().load_game()
        else:
            App.get_running_app().new_game()
        self.manager.current = 'battle'

class BattleScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation='vertical', spacing=5, padding=10)
        self.log = Label(text="Battle begins!", size_hint=(1, 0.3))
        self.btn = Button(text="Attack", size_hint=(1, 0.2))
        self.btn.bind(on_release=lambda x: self.take_turn())
        self.layout.add_widget(self.log)
        self.layout.add_widget(self.btn)
        self.add_widget(self.layout)

    def take_turn(self):
        damage = random.randint(5, 20)
        App.get_running_app().game_state['enemy_hp'] -= damage
        self.log.text = f"You hit the enemy for {damage}!"
        if App.get_running_app().game_state['enemy_hp'] <= 0:
            self.log.text += "\nEnemy defeated! Auto-saving..."
            App.get_running_app().save_game()

class StarFallApp(App):
    def build(self):
        self.game_state = {}
        sm = ScreenManager()
        sm.add_widget(MainMenu(name='menu'))
        sm.add_widget(BattleScreen(name='battle'))
        return sm

    def new_game(self):
        self.game_state = {'enemy_hp': 100, 'battles_won': 0}
        self.save_game()

    def save_game(self):
        store.put('player', **self.game_state)

    def load_game(self):
        self.game_state = store.get('player')

if __name__ == '__main__':
    StarFallApp().run()
